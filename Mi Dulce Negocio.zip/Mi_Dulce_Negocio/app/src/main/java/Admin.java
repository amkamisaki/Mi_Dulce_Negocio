public class Admin {

    private int id;
    private String name;
    private String password;

    public receiveOrder (Order order) {
        order.status = "received";
    }
    public rejectOrder (Order order) {
        order.status = "rejected";
    }
    public sendOrder (Order order) {
        order.status = "sent";
    }
    public finishOrder(Order order) {
        order.status = "finished"
    }
    
}
